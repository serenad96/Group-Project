/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cafemenu;

import javafx.scene.control.Label;

/**
 *
 * @author Shado
 */
public class Drink {
     protected double total;  
     Label Label_Total;
       
        public void setTotal() {
         Label_Total.setText("Total: " + total); 
     }
    
    public double getTotal(double total) {
        return total;      
    }
    
      @Override
      public String toString() {
           return "" + total;
           
       }
    
}
