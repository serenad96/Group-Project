package com.mycompany.cafemenu;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.scene.*;

public class PrimaryController {

   private double total;
   //@FXML
}

